# Handoff: School Memories Photo Album + Phone Photo-Drop App

## Overview
A two-part product for documenting a student's last weeks of school:

1. **The Album** (`School Memories Album.dc.html`) — a print-ready 8×8in square photo book, designed as 22 two-page spreads (44 pages). Users fill photo slots and edit captions; final output is a double-sided PDF sent to a photo-book printer.
2. **Photo Drop** (`Photo Drop.dc.html`) — a mobile-first companion app. Every photo slot in the book is listed as a tappable box grouped by spread; tapping opens the phone's camera roll and the photo lands directly in the corresponding album slot (shared storage). Shows fill progress (N of 51 photos).

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, not production code to copy directly. The task is to **recreate these designs in the target codebase's environment** (React, Next.js, native, etc.) using its established patterns — or, if no codebase exists yet, choose an appropriate stack. A sensible production shape: a web app with cloud photo storage (so uploads from a phone appear in the album in real time), a book-renderer that outputs the fixed-size spreads, and server-side PDF generation (e.g. headless Chromium print-to-PDF) for the print file.

Notes on the bundled files:
- The two `.dc.html` files contain the full markup inside `<x-dc>…</x-dc>` plus a small logic class in a `<script data-dc-script>` tag. All styling is **inline styles** on elements — read them as the source of truth for exact values.
- `doc-page.js` is a helper web component that renders each `<section class="page">` as a fixed-size printed page (16×8in spreads here) with `@page{margin:0}` print CSS. In production, replicate its two behaviors: fixed page boxes with `overflow:hidden`, and one page per printed sheet.
- `image-slot.js` is the photo-slot component: a drag/tap-to-upload placeholder with persistence, cover-fit rendering, and pan/zoom reframing (double-click to reposition/scale the photo within its frame; crop state persists). Recreate this behavior — it's core UX for both surfaces.
- The prototype persists photos in a sidecar JSON keyed by slot `id`; both files use the **same slot ids**, which is how uploads in Photo Drop appear in the Album. In production this becomes a shared datastore keyed the same way.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy are final. Recreate pixel-perfectly. The playful placeholder/caption copy is intentional content, not lorem ipsum — keep it as editable default text.

## Design Tokens
Colors:
- Paper (page background): `#FAF8F4`
- Tinted paper (alternate pages, info bars): `#F3EFE8`
- Photo-well background (behind full-bleed slots): `#EFEBE4`
- Ink (primary text): `#1A1816` (also the dark back-cover background)
- Body/secondary text: `#4A453E`
- Muted labels: `#8A837A`
- Faint (folios/page numbers): `#B5AEA3`
- Hairlines: `#E3DED6` (on paper), `#DDD6CB` (on tinted paper)
- Signature/dotted lines: `#C9C1B4`
- Dark-page dim text: `#B5AEA3`; dark hairline: `#4A453E`

Typography (Google Fonts):
- **EB Garamond** (serif) — all display and body text. Weights 400/500/600 + italics. Italic is used heavily for captions and quotes.
- **Archivo** (sans) — small-caps-style labels only: uppercase, 9–11px, letter-spacing 0.1em–0.3em, colors `#8A837A`/`#B5AEA3`.

Type scale (album): title 54px/500; section quotes 22–28px italic; intro lede 24px italic; journal body 14px/1.75–1.8; captions 14–16px italic; labels 9–11px Archivo uppercase.
Line style: 1px solid hairlines as section rules; 1px dotted `#C9C1B4` for fill-in lines.
Radii: none in the album (sharp corners); Photo Drop slots use 4px.

## The Album — page geometry
- Each `<section class="page">` is one **spread**: 16in × 8in (two facing 8×8in pages). At 96dpi: 1536×768px.
- Spreads print full-bleed, `overflow:hidden`, one per sheet; printed double-sided and bound, or sliced at the fold by a photo-book service.
- Standard page padding: 0.6–0.8in. Facing pages are usually separated by a 1px `#E3DED6` vertical border on the right half's left edge.
- Folio numbers: Archivo 9px, letter-spacing 0.2em, `#B5AEA3`, at the bottom outer area of each page. Folios over photos are white with `text-shadow: 0 0 6px rgba(0,0,0,0.55)` and `mix-blend-mode:difference`. Full-bleed spreads (3, 10, 19) carry no folios. Folio numbering counts all pages: 02·03 … 42·43.
- A boolean setting `showPageNumbers` (default true) toggles all folios.

## The Album — the 22 spreads (in order)
Read exact layouts from the file; summary:
1. **Cover wrap** — left half: dark back cover (`#1A1816`, centered "the end (for now)"); right half: front cover — label, 1.5in circle photo slot (`cover-circle`), "The last days of / 3 Idiots & the Stooges" 54px, footer rule with "Memories, mostly true · 2026".
2. **Intro | opening photo** — left: "An honest warning" + italic lede + body; right: full-page slot `s2-photo`.
3. **Full-bleed** — `s3-full` across both pages; caption plate (paper bg, 14px padding) bottom-right.
4. **Two photos + journal** — left: two stacked photo rows with side captions (`s4-a`, `s4-b`); right: 3.3in photo `s4-main` + journal entry block.
5. **Quotes | photo** — tinted paper; left: 3 large italic quotes with attributions; right: photo `s5-photo` + "Exhibit A." caption.
6. **Grid | quiet** — left: 2×2 grid (`s6-a`–`s6-d`); right: 4in-wide full-height photo `s6-main` + right-aligned one-liner column.
7. **Field notes | signatures** — left: dated Mon–Thu entries with tiny slot `s7-tiny`; right (tinted): "Sign here, idiots" + 7 ruled lines (space-evenly).
8. **The cast** — 6 circle slots (`cast-1`–`cast-6`) in one row with names + playful roles.
9. **Full-bleed II** (`s10-full`), caption plate top-left.
10. **Filmstrip** — 6 vertical frames (`strip-1`–`strip-6`) with tiny captions.
11. **Photo | journal II** — full-page photo left (`s12-photo`), titled journal right.
12. **Superlatives** — tinted; 6 award lines with dotted leaders + photo `s13-photo`.
13. **Grid II | quiet II** (`s14-a`–`s14-d`, `s14-main`).
14. **Photo | Overheard vol. II** (`s15-photo` + 3 quotes).
15. **Places** — 3 tall photo columns (`place-1`–`place-3`) with name + "why it mattered" lines.
16. **Field notes II | photo** (`s17-tiny`, `s17-photo`), Mon–Fri.
17. **Two photos + journal III** (`s18-a`, `s18-b`, `s18-main`).
18. **Full-bleed III** (`s19-full`).
19. **Last firsts** — tinted; 5 checkbox lines with dotted leaders + date, photo `s20-photo`.
20. **Grid III | big quote** (`s21-a`–`s21-d`; right: 28px italic pull-quote).
21. **Wildcards** — two large free slots (`s22-a`, `s22-b`).
22. **Letter | closing** — left: "Dear future me," letter; right: full-page `s8-photo` with centered "see you around." plate near bottom.

Grid guard used throughout: `minmax(0,1fr)` tracks so photo slots can't blow out their columns.

## Photo Drop app — layout & behavior
- Max width 430px, centered, paper background; desk background `#EFEBE4` outside.
- **Sticky header**: "Photo drop" label + book title; "Open book" bordered button (links to the album); progress line "N of 51 photos in the book · P%" over a 3px progress bar (ink on hairline, width transition 0.4s).
- **Info bar** (tinted): "Tap any box to add a photo…"
- **Sections**: one per spread, header = spread name + italic page range (e.g. "The cast — pages 14–15"). Body = 3-column grid, 10px gap; each cell = 112px-tall photo slot (rounded 4px) + 9px uppercase label below. Wide/hero slots span 2–3 columns (`span` per slot in the data). Touch targets ≥ 44px.
- **Footer** (tinted): "When you're done" note.
- Slot list data lives in the logic class of `Photo Drop.dc.html` (id, label, hint, span, grouped by spread) — use it as the canonical slot manifest.
- Progress: prototype polls the persistence store every 4s and counts filled slots; in production, derive reactively from the datastore.
- Page ranges in section headers match the album's printed folios exactly.

## Interactions & State
- **Photo slot**: empty → dashed/labelled placeholder; tap/click opens file picker (`accept="image/*"` — on mobile this offers camera + camera roll); drag-and-drop on desktop. Filled → cover-fit image; double-click (or Edit control) enters reframe mode: drag to pan, scroll/handles to scale, Escape/click-out commits. Crop persists with the image.
- **Shared storage**: slot id → {image, crop}. Uploading in Photo Drop must immediately reflect in the album (same id).
- **Editable text**: all captions/quotes/names in the album are user-editable content.
- **Export**: "print-ready PDF" = one 16×8in sheet per spread, zero margins, full bleed, exact colors (`print-color-adjust: exact`).

## State Management
- `photos: Record<slotId, {url, crop:{x,y,scale}}>` — shared across both surfaces (cloud store in production).
- `showPageNumbers: boolean` (album setting).
- Album text content: editable copy blocks (CMS-lite or contentEditable persistence).
- Progress = count(filled ids) / 51.

## Assets
No external images — all photo areas are user-filled slots. Fonts from Google Fonts (EB Garamond, Archivo). No icons or emoji.

## Screenshots
`screenshots/` contains reference captures: `01–12-album.png` walk through the album's spreads in order (empty photo slots show as placeholders); `01–03-photo-drop.png` show the companion app top, middle, and bottom. Use them to sanity-check layout — the HTML files remain the source of truth for exact values.

## Files
- `School Memories Album.dc.html` — the 22-spread print book (source of truth for all album layouts/copy).
- `Photo Drop.dc.html` — the mobile companion app (source of truth for app layout + slot manifest).
- `doc-page.js` — page/print shell used by the prototype (reference for print geometry).
- `image-slot.js` — photo-slot component used by the prototype (reference for upload/reframe UX and persistence keys).
